EMAIL_USE_TLS =True
EMAIL_HOST = "smtp.gmail.com"
EMAIL_HOST_USER ='raghavbhai0789@gmail.com'
EMAIL_HOST_PASSWORD = "rzkm vmph svci iazi"
EMAIL_PORT = 587